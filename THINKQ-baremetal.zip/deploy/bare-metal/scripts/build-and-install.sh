#!/usr/bin/env bash
set -euo pipefail

if [ "${EUID}" -ne 0 ]; then
  exec sudo bash "$0" "$@"
fi

APP_ROOT=/opt/thinkq
FRONTEND_DIR="$APP_ROOT/frontend"
BACKEND_DIR="$APP_ROOT/backend"
VENV_DIR="$APP_ROOT/venvs/analytics"

if [ ! -d "$FRONTEND_DIR" ] || [ ! -d "$BACKEND_DIR" ]; then
  echo "Expected frontend/ and backend/ under $APP_ROOT" >&2
  exit 1
fi

chown -R thinkq:thinkq "$APP_ROOT/frontend" "$APP_ROOT/backend"

run_as_thinkq() {
  su -s /bin/bash thinkq -c "$1"
}

echo "Building frontend..."
run_as_thinkq "cd '$FRONTEND_DIR' && npm ci && npm run build"

echo "Installing Node service dependencies..."
for service in auth-user-service admin-service tickets-service notifications-service; do
  run_as_thinkq "cd '$BACKEND_DIR/$service' && npm install --omit=dev"
done

echo "Building analytics virtualenv..."
run_as_thinkq "python3 -m venv '$VENV_DIR'"
run_as_thinkq "'$VENV_DIR/bin/pip' install --upgrade pip"
run_as_thinkq "'$VENV_DIR/bin/pip' install -r '$BACKEND_DIR/analytics-service/requirements.txt'"

echo "Building Java data service..."
run_as_thinkq "cd '$BACKEND_DIR/data-service' && mvn clean package -DskipTests"

echo "Installing systemd units..."
for unit in thinkq-data thinkq-auth thinkq-admin thinkq-tickets thinkq-notifications thinkq-analytics; do
  cp "$APP_ROOT/deploy/bare-metal/systemd/${unit}.service" /etc/systemd/system/
done
systemctl daemon-reload


echo "Installing Nginx config..."
cp "$APP_ROOT/deploy/bare-metal/nginx/thinkq.conf" /etc/nginx/conf.d/thinkq.conf
nginx -t

echo "Build and installation steps completed."
echo "Start services with: systemctl enable --now valkey thinkq-data thinkq-auth thinkq-admin thinkq-tickets thinkq-notifications thinkq-analytics nginx"
